function enhancementErrorText(message){
 if(/Another enhancement is running|Helper busy/.test(message))return E('本机正在处理另一个任务，请在“视频处理”查看进度，完成后重试。','Another local task is running. Check Video processing and retry when it finishes.');
 if(/Face restoration is not installed/.test(message))return E('脸部模型尚未安装或验证失败。运行本机增强包中的 install-face.command 后重新连接。','Face model is not installed or verification failed. Run install-face.command and reconnect.');
 if(/No usable face detected/.test(message))return E('没有检测到可修复的脸。遮挡过重无法可靠还原，请换一段五官更清楚的片段。','No usable face was detected. Heavy masking cannot be reliably restored; try a clearer clip.');
 if(/Complete and confirm a face preview/.test(message))return E('请先用当前参数生成脸部预览，并确认后再处理整段。','Complete and confirm a face preview with the current settings first.');
 if(/SeedVR2 currently supports up to/.test(message))return E('这段视频超过强力 AI 的 1080p 输入上限。请选择“自然修复”保留原分辨率；强力 AI 支持横版 1920×1080 或竖版 1080×1920。','This video exceeds the Strong AI 1080p input limit. Choose Natural restoration to preserve its original resolution.');
 return message;
}
// Authenticated loopback client. Full results are retained until explicit deletion.
const ENHANCER_URL = 'http://127.0.0.1:8765';
const E = (zh,en) => LANG === 'zh' ? zh : en;
let enhancementToken = '', enhancementSource = null, enhancementBusy = false, enhancementJob = null;
let enhancementUrls = [], enhancementOutputUrl = null, enhancementPreviewMode = null, enhancementPreviewOffset = 0;
let helperHealth = null, taskPolling = false, comparisonActive = false;
function enhancementStatus(text) { $('enhance-status').textContent = text; }
async function enhancementRequest(path,options={}) {
  const response = await fetch(ENHANCER_URL+path,{...options,signal:options.signal || ((!options.method || options.method==='GET') && !path.endsWith('/result') ? AbortSignal.timeout(15000):undefined),headers:{...options.headers,'X-WeScreen-Token':enhancementToken},cache:'no-store'});
  if(!response.ok){const error=await response.json().catch(()=>({}));throw new Error(error.error || `HTTP ${response.status}`);} return response;
}
function clearEnhancementPreview() {
  comparisonActive = false;$('compare-zoom').value='1';for(const id of ['enhance-original','enhance-output'])$(id).style.width='100%';
  for(const id of ['enhance-original','enhance-output']){const video=$(id);video.pause();video.removeAttribute('src');video.load();}
  enhancementUrls.forEach(url=>URL.revokeObjectURL(url));enhancementUrls=[];enhancementOutputUrl=null;
}
function updateTaskConnection(connected, connecting=false) {
  $('tasks-connection').dataset.state=connecting ? 'connecting' : connected ? 'connected' : 'offline';
  const key=connecting ? 'helperConnecting' : connected ? 'helperConnected' : 'helperDisconnected';
  $('tasks-connection-label').dataset.i18n=key;$('tasks-connection-label').textContent=L(key);
  $('tasks-connect').hidden=connected;
  $('tasks-connect').disabled=connecting;
  $('tasks-connect').textContent=L(connecting ? 'helperConnecting':'autoConnect');
}
let helperConnecting=null, helperConnectionEpoch=0;
async function discoverHelperToken(challenge=''){
 const response=await fetch(ENHANCER_URL+'/connect'+(challenge?'?challenge='+encodeURIComponent(challenge):''),{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',cache:'no-store',signal:AbortSignal.timeout(3000)});
 if(!response.ok){const error=await response.json().catch(()=>({}));throw new Error(error.error || `HTTP ${response.status}`);}
 const data=await response.json();if(typeof data.token!=='string' || !/^[A-Za-z0-9_-]{20,128}$/.test(data.token))throw new Error(E('本机连接响应无效。','Invalid helper connection response.'));
 enhancementToken=data.token;$('enhance-token').value=enhancementToken;
}
function openNativePairing(origin,challenge){
 const link=document.createElement('a');link.href='wescreen-helper://pair?'+new URLSearchParams({origin,challenge});document.body.append(link);link.click();link.remove();
}
async function repairHelperPairing(){
 if(!chrome.runtime.id)throw new Error(E('请在扩展页面连接。','Connect from the extension page.'));
 const challenge=Array.from(crypto.getRandomValues(new Uint8Array(32)),v=>v.toString(16).padStart(2,'0')).join('');
 openNativePairing('chrome-extension://'+chrome.runtime.id,challenge);
 const message=E('请在弹出的本机 WeScreen 窗口允许连接。正在等待确认…','Allow connection in the local WeScreen window. Waiting for approval…');$('helper-status').textContent=message;$('tasks-status').textContent=message;
 const deadline=Date.now()+45000;
 while(Date.now()<deadline){try{await discoverHelperToken(challenge);return;}catch(error){if(!/paired|fetch|Failed|Network|HTTP 5|timed out|timeout|aborted/i.test(error.message))throw error;}await new Promise(r=>setTimeout(r,750));}
 throw new Error(E('本机授权尚未完成。请更新增强包并运行 install-launcher.command，再点击自动连接；已有文件保留。','Local approval did not finish. Update the helper and run install-launcher.command, then retry. Existing files are preserved.'));
}
async function connectHelper(options={}){
 // A user retry must not disappear into a background discovery already in flight.
 if(helperConnecting){const result=await helperConnecting;if(result || !options.repair)return result;}
 helperConnectionEpoch++;
 helperConnecting=(async()=>{
  $('helper-check').disabled=true;$('helper-check').textContent=E('连接中…','Connecting…');enhancementToken=$('enhance-token').value.trim();helperHealth=null;updateTaskConnection(false,true);updateEnhancementMode();$('helper-status').textContent=E('正在自动连接本机程序…','Connecting to local helper…');$('tasks-status').textContent=$('helper-status').textContent;
  try{
   try{
    if(options.launch){
     // Probe first: a running helper needs pairing, not another external start request.
     try{await discoverHelperToken();}catch(error){
      if(/paired/.test(error.message))throw error;
      if(!/fetch|Failed|Network|timed out|timeout|aborted/i.test(error.message))throw error;
      const link=document.createElement('a');link.href='wescreen-helper://start';document.body.append(link);link.click();link.remove();
      const deadline=Date.now()+12000;while(true){try{await discoverHelperToken();break;}catch(startError){
       if(/paired/.test(startError.message)){throw new Error(E('本机程序已启动，需要授权。请再次点击自动连接，在本机窗口允许连接。','Helper started and needs approval. Click Auto connect again to approve in the local window.'));}
       if(Date.now()>=deadline)throw startError;await new Promise(resolve=>setTimeout(resolve,600));
      }}
     }
    }
    else if(!enhancementToken)await discoverHelperToken();
    try{helperHealth=await(await enhancementRequest('/health',{signal:AbortSignal.timeout(4000)})).json();}catch(error){if(!/401|Invalid local access token/.test(error.message))throw error;await discoverHelperToken();helperHealth=await(await enhancementRequest('/health',{signal:AbortSignal.timeout(4000)})).json();}
   }catch(error){if(!options.repair || !/paired with another/.test(error.message))throw error;await repairHelperPairing();helperHealth=await(await enhancementRequest('/health',{signal:AbortSignal.timeout(4000)})).json();}
   if(Number(helperHealth.protocolVersion||1)>2){helperHealth=null;throw new Error('Incompatible helper protocol version. Update the extension and helper together.');}
   if(chrome.storage.session)await chrome.storage.session.set({enhancementToken});
   $('helper-status').textContent=E('已连接 · ','Connected · ')+[E('自然修复','Natural restoration'),helperHealth.ai ? 'AI 2×':'',helperHealth.strong ? 'SeedVR2':''].filter(Boolean).join(' / ');$('helper-connection').open=false;$('tasks-status').textContent=$('helper-status').textContent;updateEnhancementMode();renderEnhancementTasks().catch(()=>{});return helperHealth;
  }catch(error){$('tasks-connection').dataset.reason=/paired/.test(error.message)?'pairing':/version|incompatible/.test(error.message)?'version':'unreachable';$('helper-status').textContent=/paired with another/.test(error.message) ? E('检测到另一扩展的配对。点击自动连接，在本机窗口允许一次；以后两个扩展都能自动连接，无需重置。','Another extension is paired. Click Auto connect and approve once in the local window; both extensions will reconnect without resetting.') : /version|incompatible|Incompatible/.test(error.message)?E('扩展与本机程序协议不匹配，请使用配套安装包更新后重试。','Extension/helper protocol mismatch. Update both using matching packages.') : /授权尚未|approval did not|本机程序已启动|Helper started/.test(error.message)?error.message:E('未连接本机程序。请先启动它，窗口打开时会自动重试。','Local helper unavailable. Start it; this dialog retries automatically.');$('tasks-status').textContent=$('helper-status').textContent;updateEnhancementMode();return null;}
 })();try{return await helperConnecting;}finally{helperConnecting=null;$('helper-check').disabled=false;$('helper-check').textContent=L('autoConnect');updateTaskConnection(!!helperHealth);}
}
function enhancementControls(busy) {
  enhancementBusy=busy;$('enhance-progress').hidden=!busy;$('enhance-cancel').hidden=!busy;
  for(const id of ['enhance-preview','enhance-full','enhance-mode','enhance-token','enhance-start','preview-seconds'])$(id).disabled=busy;
  $('enhance-cancel').disabled=!busy || !enhancementJob;
  updateEnhancementMode();
}
function updateEnhancementMode() {
  $('helper-actions').hidden=!!helperHealth;$('helper-auto-hint').hidden=!!helperHealth;$('model-setup-link').hidden=!helperHealth || (helperHealth.ai && helperHealth.strong);
  for(const [mode,key] of [['strong','modeStrong'],['ai','modeAI']]){const option=$('enhance-mode').querySelector(`[value="${mode}"]`),reason=!helperHealth ? E('先连接本机程序','connect helper first'):!helperHealth[mode] ? E('未安装模型','model not installed'):enhancementSource&&(enhancementSource.captureContent==='detail'||Math.min(enhancementSource.width||0,enhancementSource.height||0)>=1080)?E('仅用于低清视频，可能改字','low-resolution video only; may alter text'):'';option.disabled=!!reason;option.textContent=L(key)+(reason ? ` (${reason})`:'');}
  $('model-availability').textContent=!helperHealth ? E('AI 模式暂不可选：尚未连接本机程序。启动后会自动检测模型。','AI modes unavailable: connect the local helper to check installed models.') : [!helperHealth.strong ? E('强力 AI 未安装：打开安装说明，安装 SeedVR2 模型。','Strong AI unavailable: open setup instructions to install SeedVR2.'):'',!helperHealth.ai ? E('轻量 AI 未安装：请使用完整的新版本机程序包。','Lightweight AI unavailable: use the complete updated helper package.'):''].filter(Boolean).join(' ');
  $('model-availability').hidden=!helperHealth;$('enhance-disabled-reason').hidden=!helperHealth;
  for(const option of $('preview-seconds').options)option.textContent=option.value+E(' 秒',' seconds');
  $('enhance-preview').textContent=E('预览 ','Preview ')+$('preview-seconds').value+E(' 秒',' seconds');
  if($('enhance-mode').selectedOptions[0]?.disabled)$('enhance-mode').value='natural';
  const mode=$('enhance-mode').value;
  $('enhance-mode-hint').textContent=mode==='strong' ? E('仅适用于低清视频，SeedVR2 可能改变人脸与字幕。处理较慢，建议先预览，也可直接增强整段；输入/输出最高 1080p。','For low-resolution video only. SeedVR2 can alter faces and subtitles. Processing is slow; preview is recommended, or process the full video directly. Up to 1080p input/output.') : mode==='natural' ? E('保留原分辨率，减少压缩块和噪点，轻度锐化。','Preserves resolution, reduces compression artifacts and noise, and gently sharpens.') : E('先选择片段预览。明暗增强仍为 SDR，AI 无法保证还原丢失细节。','Preview a selected clip first. Brightness output stays SDR; AI cannot guarantee lost details are recovered.');
  $('enhance-preview').disabled=enhancementBusy || !enhancementSource || !helperHealth;
  $('enhance-full').disabled=enhancementBusy || !enhancementSource || !helperHealth;
  $('enhance-disabled-reason').textContent=enhancementBusy ? E('正在处理，请等待完成或取消当前任务。','Processing: wait or cancel the current task.') : !enhancementSource ? E('请先从录像库选择一段视频，再使用画质增强。','Select a video in the library to enable enhancement.') : !helperHealth ? E('按钮暂不可用：本机程序尚未连接。','Buttons unavailable: local helper is not connected.') : '';
}
async function openEnhancement(entry=null) {
  if(enhancementBusy){navigateWorkspace('tasks');return;}
  enhancementSource=entry;if(typeof facePreviewReceipt!=='undefined')facePreviewReceipt=null;hdrInput.checked=false;masterInput.checked=false;enhancementPreviewMode=null;comparisonActive=false;clearEnhancementPreview();
  $('enhance-title').textContent=entry ? E('画质增强：','Enhance: ')+entry.name : L('helperConnection');
  $('enhance-estimate').textContent='';$('enhance-start').value='0';$('enhance-progress').value=0;
  $('enhance-panel').showModal();$('helper-connection').open=false;
  enhancementStatus('');
  if(entry){const blob=await readStore('videos',entry.id);if(!blob)throw new Error(L('errEmpty'));const url=URL.createObjectURL(blob);enhancementUrls.push(url);$('enhance-original').src=url;}
  await connectHelper();
}
function resultName(task) {
  const label=task.mode==='face' ? 'face-generated' : task.smartTail ? 'merged-trimmed' : task.mode==='merge' ? (task.compress ? 'merged-compressed-1080p':'merged') : task.mode==='trimstatic' ? 'trimmed' : task.mode==='watermark' ? 'patched' : task.mode==='edit' ? 'edited' : task.mode==='strong' ? 'SeedVR2' : task.mode==='ai' ? 'AI-2x' : task.mode;
  return `${(task.name || 'video').replace(/\.(mp4|webm)$/i,'')}-${label}${task.encoding==='master'?'-444-master':''}${task.preview ? '-preview' : ''}.mp4`;
}
const hdrChoice=document.createElement('label');hdrChoice.className='check';const hdrInput=document.createElement('input');hdrInput.type='checkbox';hdrInput.id='enhance-hdr-sdr';hdrChoice.append(hdrInput,document.createTextNode(E('HDR 转 SDR（另存，原视频保留）','Convert HDR to SDR (save a copy)')));$('enhance-mode-hint').after(hdrChoice);
const masterChoice=document.createElement('label');masterChoice.className='check';const masterInput=document.createElement('input');masterInput.type='checkbox';masterChoice.append(masterInput,document.createTextNode(E('4:4:4 母带（文件较大，部分播放器不支持；另存保留原片）','4:4:4 master (larger; some players unsupported; original retained)')));hdrChoice.after(masterChoice);
async function submitProcessing(source,options) {
  enhancementToken=$('enhance-token').value.trim();if(!enhancementToken)throw new Error(L('helperOffline'));
  const blob=await readStore('videos',source.id);if(!blob)throw new Error(L('errEmpty'));
  const query=new URLSearchParams({mode:options.mode,preview:options.preview ? '1':'0',start:String(options.start || 0),end:String(options.end || 0),sourceId:source.id,name:source.name});
  options={...options,encoding:options.encoding || (source===enhancementSource&&masterInput.checked&&!options.preview?'master':'compatible')};query.set('encoding',options.encoding);
  if(['ai','strong'].includes(options.mode)&&(source.captureContent==='detail'||Math.min(source.width||0,source.height||0)>=1080))throw new Error(E('AI 放大仅用于低清来源，可能改变文字。文字或高清来源请选择自然修复。','AI upscaling is for low-resolution sources and may alter text. Use Natural restoration for text or HD sources.'));
  query.set('captureContent',source.captureContent || 'auto');
  if(options.toneMap ?? (source===enhancementSource && hdrInput.checked))query.set('toneMap','1');
  if($('enhance-strength') && ['natural','basic','light','ai'].includes(options.mode))query.set('strength',options.strength ?? $('enhance-strength').value);
  if(options.mode==='face'){
    query.set('faceFidelity',String(options.faceFidelity ?? faceFidelity.value));query.set('strength',String(options.strength ?? $('enhance-strength').value));
    if(!options.preview){if(!options.facePreviewId && (!facePreviewMatches() || !faceConfirm.checked))throw new Error(E('先预览并确认脸部变化。','Preview and confirm the face changes first.'));query.set('facePreviewId',options.facePreviewId || facePreviewReceipt.id);}
  }
  if(options.audioPreset)query.set('audioPreset',options.audioPreset);
  if(options.watermark)query.set('watermark',options.watermark.join(','));
  if(options.requireSilence!==undefined)query.set('requireSilence',options.requireSilence?'1':'0');
  if(options.previewSeconds)query.set('previewSeconds',String(options.previewSeconds));
  if(options.crop)query.set('crop',options.crop.join(','));
  if(options.landscape)query.set('landscape','1');
  if(options.rotation!==undefined)query.set('rotation',String(options.rotation));
  if(options.batchRef)query.set('batchRef',options.batchRef);
  // Full processing owns the helper slot; await cancellation of our playback worker.
  if(typeof stopRealtimeAI==='function')stopRealtimeAI();
  if(typeof stopSmartBackground==='function' && !await stopSmartBackground())throw new Error(E('后台修复尚未停止，请检查本机连接后重试。','Background repair could not stop; check the helper connection and retry.'));
  const job=await(await enhancementRequest('/jobs?'+query,{method:'POST',body:blob,headers:{'Content-Type':blob.type || 'application/octet-stream'}})).json();
  const task={id:job.id,sourceId:source.id,name:source.name,course:source.course || '',markers:source.markers || [],createdAt:Date.now(),state:'queued',exportFolder:source.exportFolder,...options};
  // The helper also persists sourceId/name, so a quota failure here cannot orphan the result.
  await runTx('tasks','readwrite',tx=>tx.objectStore('tasks').put(task)).catch(error=>enhancementStatus(E('任务已在本机创建；浏览器任务记录失败：','Task created locally; browser metadata could not be stored: ')+error.message));
  return task;
}
async function saveTaskResult(task) {
  return navigator.locks.request(`wescreen-save-job-${task.id}`,async()=>{
    const existing=(await readStore('recordings')).find(entry=>entry.helperJobId===task.id);
    if(existing)return existing.id;
    const info=await(await enhancementRequest(`/jobs/${task.id}`)).json();
    if(info.state!=='done')throw new Error(E('任务尚未完成。','Task has not completed.'));
    if(info.size>HEAP_LIMIT_BYTES)throw new Error(E('结果超过录像库单文件限制，请直接导出；结果仍在本机。','Result exceeds the library per-file limit. Export directly; it remains on this device.'));
    const estimate=await navigator.storage?.estimate?.();
    if(!hasUnlimitedStorage() && estimate && estimate.quota-estimate.usage<info.size*1.1)throw new Error(E('录像库存储空间不足，请直接导出。','Library storage is insufficient. Export directly.'));
    const blob=await(await enhancementRequest(`/jobs/${task.id}/result`)).blob();
    const original=await readStore('recordings',task.sourceId);
    const id=crypto.randomUUID();let savedId=id;
    const entry={id,encoding:info.encoding || task.encoding,captureContent:original?.captureContent || 'auto',frameRate:info.frameRate || original?.frameRate,averageMuxBitrate:blob.size*8/Math.max(.001,info.duration),name:resultName(task),size:blob.size,createdAt:Date.now(),duration:info.duration*1000,width:info.width,height:info.height,course:task.course || original?.course || '',markers:task.mode==='trimstatic' || task.smartTail ? (original?.markers || []).filter(m=>m.at<info.duration*1000) : task.mode==='edit' ? (original?.markers || []).filter(m=>m.at>=task.start*1000 && (!task.end || m.at<task.end*1000)).map(m=>({...m,at:m.at-task.start*1000})) : original?.markers || task.markers || [],enhancedFrom:task.sourceId,enhancement:task.mode,helperJobId:task.id,sourceMessageKey:original?.sourceMessageKey,channelId:original?.channelId,channelName:original?.channelName,channelUrl:original?.channelUrl,sourceUrl:original?.sourceUrl,channelTaskId:original?.channelTaskId,exportFolder:original?.exportFolder || task.exportFolder};
    await runTx(['recordings','videos','tasks'],'readwrite',tx=>{
      const request=tx.objectStore('recordings').getAll();request.onsuccess=()=>{
        const duplicate=request.result.find(item=>item.helperJobId===task.id);
        if(duplicate){savedId=duplicate.id;return;}
        tx.objectStore('recordings').add(entry);tx.objectStore('videos').add(blob,id);tx.objectStore('tasks').put({...task,...info,savedId:id});
      };
    });
    saveThumbnail(blob,savedId).catch(()=>{});await renderRecordingLibrary();if(typeof refreshPlaybackVersions==='function')refreshPlaybackVersions().catch(()=>{});return savedId;
  });
}
async function exportTask(task) {
  const ticket=await(await enhancementRequest(`/jobs/${task.id}/export`,{method:'POST'})).json();
  // Native download streams from disk, avoiding a multi-gigabyte Blob in the browser heap.
  if(chrome.downloads?.download){const source=task.sourceId ? await readStore('recordings',task.sourceId):null;const folder=relativeFolder(task.exportFolder || source?.exportFolder || '');return chrome.downloads.download({url:ticket.url,filename:(folder ? folder+'/':'')+resultName(task),saveAs:true});}
  else {const anchor=document.createElement('a');anchor.href=ticket.url;anchor.download=resultName(task);anchor.click();}
}
async function enhanceVideo(preview) {
  if(enhancementBusy || !enhancementSource)return;
  const source=enhancementSource,mode=$('enhance-mode').value,start=preview ? Math.max(0,$('enhance-original').currentTime || 0):0,previewSeconds=Number($('preview-seconds').value) || 5;
  if(!Number.isFinite(start) || start<0){enhancementStatus(E('预览起点无效。','Invalid preview start.'));return;}
  const began=performance.now();let task=null;enhancementControls(true);
  try {
    enhancementStatus(E('正在停止观看增强并提交任务…','Stopping playback repair and submitting task…'));$('enhance-progress').value=0;
    task=await submitProcessing(source,{mode,preview,start,previewSeconds,...(mode==='face'?{faceFidelity:Number(faceFidelity.value),strength:Number($('enhance-strength').value),facePreviewId:facePreviewReceipt?.id}:{})});enhancementJob=task.id;$('enhance-cancel').disabled=false;
    while(true){
      const info=await(await enhancementRequest(`/jobs/${task.id}`)).json();$('enhance-progress').value=info.progress || 0;
      const phase=info.detail?.phase;enhancementStatus(info.stage==='SeedVR2' ? `SeedVR2 · ${phase || E('加载模型 / 重建细节','Loading / restoring')}${info.detail ? ` ${info.detail.batch}/${info.detail.batches}`:''}` : E('本机处理中：','Processing locally: ')+Math.round((info.progress || 0)*100)+'%');
      if(info.state==='error' || info.state==='cancelled')throw new Error(info.error || L('jobCancelled'));
      if(info.state==='done'){
        if(preview){
          if(info.size>HEAP_LIMIT_BYTES)throw new Error(E('预览过大，请在任务中直接导出。','Preview is too large. Export it from Tasks.'));
          const output=await(await enhancementRequest(`/jobs/${task.id}/result`)).blob();
          if($('enhance-panel').open && enhancementSource?.id===source.id){
            if(enhancementOutputUrl)URL.revokeObjectURL(enhancementOutputUrl);
            enhancementOutputUrl=URL.createObjectURL(output);enhancementUrls.push(enhancementOutputUrl);$('enhance-output').src=enhancementOutputUrl;$('enhance-output').controls=false;
            enhancementPreviewMode=mode;enhancementPreviewOffset=start;comparisonActive=true;$('enhance-original').currentTime=start;
            const seconds=(performance.now()-began)/1000,estimate=source.duration && info.duration ? seconds*source.duration/1000/info.duration:null;
            $('enhance-estimate').textContent=E('预览耗时 ','Preview took ')+Math.ceil(seconds)+E(' 秒',' seconds')+(estimate ? E('；整段粗略估计 ','; full video roughly ')+Math.ceil(estimate/60)+E(' 分钟，随素材和负载变化。',' minutes; varies with content and load.'):'');
            enhancementStatus(E('预览已完成，检查字幕、人脸和运动后再处理整段。','Preview ready. Check text, faces and motion before processing the full video.'));
          }
          // Face previews remain locally available as receipts for full processing.
          if(mode==='face'){facePreviewReceipt={id:task.id,signature:faceSettingsSignature()};faceConfirm.checked=false;}
          else {await enhancementRequest(`/jobs/${task.id}`,{method:'DELETE'});await runTx('tasks','readwrite',tx=>tx.objectStore('tasks').delete(task.id));}
        }else{await saveTaskResult({...task,...info});enhancementStatus(E('已另存到录像库，本机结果也保留，可从任务中导出。','Saved to the library. The local result is also retained and can be exported from Tasks.'));}
        break;
      }
      await new Promise(resolve=>setTimeout(resolve,700));
    }
  }catch(error){enhancementStatus(E('处理未完成或保存失败：','Processing or saving failed: ')+enhancementErrorText(error.message)+(task ? E(' 任务结果仍可在“处理任务”中查看或导出。',' Inspect or export the retained result in Tasks.') : ''));}
  finally{enhancementJob=null;enhancementControls(false);renderEnhancementTasks().catch(()=>{});}
}
// Persist the attempt before opening a save dialog so refreshes and other tabs cannot repeat it.
async function autoExportMergedTask(task) {
 if(!task.autoDownload || task.state!=='done')return;
 await navigator.locks.request('wescreen-auto-export-'+task.id,async()=>{
  const stored=await readStore('tasks',task.id);
  if(!stored?.autoDownload || stored.autoDownloadAttemptedAt)return;
  const attempted={...stored,...task,autoDownloadAttemptedAt:Date.now()};
  await runTx('tasks','readwrite',tx=>tx.objectStore('tasks').put(attempted));
  try{const downloadId=await exportTask(task);await runTx('tasks','readwrite',tx=>tx.objectStore('tasks').put({...attempted,autoDownloadId:downloadId}));}
  catch(error){await runTx('tasks','readwrite',tx=>tx.objectStore('tasks').put({...attempted,autoDownloadError:error.message}));$('tasks-status').textContent=E('自动下载未完成，可点击任务的“导出结果”重试：','Automatic download did not finish. Use Export result to retry: ')+error.message;}
 });
}
async function renderEnhancementTasks() {
  if(taskPolling)return;taskPolling=true;
  try {
    const local=await readStore('tasks');let jobs=[],remoteChecked=false;const connectionEpoch=helperConnectionEpoch;
    // Discovery owns connection status while in flight; task refresh must not invalidate it.
    if(!helperConnecting && enhancementToken){try{jobs=(await(await enhancementRequest('/jobs')).json()).jobs;remoteChecked=true;if(!helperConnecting && connectionEpoch===helperConnectionEpoch)$('tasks-status').textContent='';}catch(error){if(!helperConnecting && connectionEpoch===helperConnectionEpoch){helperHealth=null;$('tasks-status').textContent=L('helperOffline')+' '+error.message;}}}
    else if(!helperConnecting) $('tasks-status').textContent=L('helperOffline');
    if(!helperConnecting)updateTaskConnection(connectionEpoch===helperConnectionEpoch ? remoteChecked:!!helperHealth);
    const records=await readStore('recordings');
    const merged=new Map(local.map(task=>[task.id,task]));for(const job of jobs)merged.set(job.id,{...merged.get(job.id),...job});
    const list=$('task-items');list.replaceChildren();
    $('tasks-empty').hidden=merged.size>0;list.hidden=merged.size===0;
    for(const task of [...merged.values()].sort((a,b)=>b.createdAt-a.createdAt)){
      const row=document.createElement('li');row.className='task-row';row.dataset.state=task.state;const icon=document.createElement('span');icon.className='task-media-icon';icon.innerHTML='<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="m10 8 6 4-6 4Z"/></svg>';row.append(icon);
      const title=document.createElement('strong');title.textContent=task.name || task.id;row.append(title);
      let saved=records.find(entry=>entry.helperJobId===task.id);const remote=jobs.some(job=>job.id===task.id);
      if(task.autoDownload && task.state==='done' && remote)await autoExportMergedTask(task);
      if(task.playbackAI && task.state==='done' && remote && !saved){try{const id=await saveTaskResult(task);saved={id};if(typeof completePlaybackAI==='function')await completePlaybackAI(task,id);}catch(error){$('tasks-status').textContent=error.message;}}
      const detail=document.createElement('p');detail.className='hint';detail.textContent=(saved ? L('jobSaved'):L({queued:'jobQueued',processing:'jobProcessing',done:'jobDone',error:'jobError',cancelled:'jobCancelled'}[task.state] || 'jobError'))+` · ${{natural:E('自然修复','Natural restoration'),ai:'AI 2×',strong:'SeedVR2',light:E('明暗增强','Brightness'),basic:E('基础增强','Basic enhancement'),edit:E('剪辑','Edit'),merge:task.compress ? E('合并压缩 · 1080p MP4','Compressed merge · 1080p MP4'):E('合并','Merge'),audio:E('声音修复','Audio repair'),face:E('脸部修复（生成式）','Face restoration (generative)')}[task.mode] || task.mode}${task.size ? ' · '+fmtBytes(task.size):''}${task.preview ? ' · '+L('enhancedPreview'):''}`;row.append(detail);
      if(task.sequence && task.detail){const stage=document.createElement('p');stage.className='hint';stage.textContent=E('当前阶段：','Current stage: ')+task.detail;row.append(stage);}
      if(task.error || (!remote && remoteChecked)){const error=document.createElement('p');error.className='hint alert';error.textContent=task.error ? enhancementErrorText(task.error) : L('taskLost');row.append(error);}
      if(task.autoDownloadError){const error=document.createElement('p');error.className='hint alert';error.textContent=E('自动下载未完成，请点击“导出结果”：','Automatic download did not finish. Use Export result: ')+task.autoDownloadError;row.append(error);}
      if(['queued','processing'].includes(task.state) && remote){const progress=document.createElement('progress');progress.max=1;progress.value=task.progress || 0;row.append(progress);const percent=document.createElement('span');percent.className='task-percent';percent.textContent=Math.round((task.progress || 0)*100)+'%';row.append(percent);}
      const buttons=document.createElement('div');buttons.className='controls task-actions';
      if(['error','cancelled'].includes(task.state) && task.sourceId){const retry=document.createElement('button');retry.type='button';retry.textContent=E('重试','Retry');retry.onclick=async()=>{retry.disabled=true;try{const source=await readStore('recordings',task.sourceId);if(!source || source.deletedAt)throw new Error(E('原视频已删除，无法重试。','Original deleted; cannot retry.'));if(task.smartTail)await queueSmartTail(source.id,task.requireSilence!==false);else if(task.mode==='merge')await mergeRecordingParts(source,task.compatible,{compress:task.compress,autoDownload:task.autoDownload});else await submitProcessing(source,{mode:task.mode,encoding:task.encoding,toneMap:task.toneMap,preview:task.preview,start:task.start,end:task.end,crop:task.crop,rotation:task.rotation,audioPreset:task.audioPreset,strength:task.strength,faceFidelity:task.faceFidelity,facePreviewId:task.facePreviewId,watermark:task.watermark,requireSilence:task.requireSilence});await renderEnhancementTasks();}catch(error){$('tasks-status').textContent=error.message;}finally{retry.disabled=false;}};buttons.append(retry);}
      if(task.state==='done' && remote){if(!saved)buttons.append(libraryButton('saveLibrary',async()=>{await saveTaskResult(task);await renderEnhancementTasks();}));buttons.append(libraryButton('exportResult',()=>exportTask(task)));}
      if(['queued','processing'].includes(task.state) && remote)buttons.append(libraryButton('cancelTask',async()=>{await enhancementRequest(`/jobs/${task.id}`,{method:'DELETE'});await renderEnhancementTasks();}));
      else buttons.append(libraryButton('deleteTask',async()=>{
        if(!confirm(E('删除任务及本机处理结果？录像库已保存的版本不受影响。','Delete this task and its local result? Saved library versions are unaffected.')))return;
        if(remote)await enhancementRequest(`/jobs/${task.id}`,{method:'DELETE'});await runTx('tasks','readwrite',tx=>tx.objectStore('tasks').delete(task.id));await renderEnhancementTasks();
      }));
      row.append(buttons);list.append(row);
    }
  }finally{taskPolling=false;}
}
function syncComparison() {
  if(!comparisonActive || !$('enhance-output').src)return;
  const master=$('enhance-original'),slave=$('enhance-output'),t=Math.max(0,master.currentTime-enhancementPreviewOffset);
  if(Number.isFinite(slave.duration) && t>slave.duration){master.pause();slave.pause();return;}
  if(Math.abs(slave.currentTime-t)>.15)slave.currentTime=t;
  slave.playbackRate=master.playbackRate;master.muted=true;slave.muted=false;
  if(master.paused)slave.pause();else slave.play().catch(()=>{});
}
for(const event of ['play','pause','seeking','timeupdate','ratechange'])$('enhance-original').addEventListener(event,syncComparison);
$('enhance-output').onended=()=>{if(comparisonActive)$('enhance-original').pause();};
$('enhance-compare').onclick=async()=>{if(!comparisonActive)return;const master=$('enhance-original');if(master.paused){const length=$('enhance-output').duration;if(master.currentTime<enhancementPreviewOffset || master.currentTime>=enhancementPreviewOffset+length)master.currentTime=enhancementPreviewOffset;await master.play();}else master.pause();syncComparison();};
$('enhance-frame').onclick=()=>{const master=$('enhance-original');master.pause();master.currentTime+=1/30;syncComparison();};
$('enhance-use-position').onclick=()=>{$('enhance-start').value=$('enhance-original').currentTime.toFixed(1);};
$('enhance-zoom').onchange=()=>document.querySelector('.enhance-comparison').classList.toggle('native-size',$('enhance-zoom').checked);
$('enhance-mode').onchange=()=>{enhancementPreviewMode=null;comparisonActive=false;$('enhance-original').pause();$('enhance-output').pause();$('enhance-output').removeAttribute('src');$('enhance-output').load();$('enhance-estimate').textContent='';updateEnhancementMode();};
$('enhance-preview').onclick=()=>enhanceVideo(true);$('enhance-full').onclick=()=>enhanceVideo(false);
$('enhance-cancel').onclick=()=>enhancementJob && enhancementRequest(`/jobs/${enhancementJob}`,{method:'DELETE'}).catch(error=>enhancementStatus(error.message));
$('enhance-close').onclick=()=>{$('enhance-panel').close();clearEnhancementPreview();};
$('enhance-panel').addEventListener('cancel',()=>clearEnhancementPreview());
$('enhance-go-tasks').onclick=()=>{$('enhance-panel').close();clearEnhancementPreview();navigateWorkspace('tasks');};
$('helper-check').onclick=()=>connectHelper({repair:true,launch:true});
$('enhance-token').oninput=()=>{helperHealth=null;updateEnhancementMode();};
window.addEventListener('wescreen-language',()=>{updateEnhancementMode();if(workspaceView==='tasks')renderEnhancementTasks().catch(()=>{});});
if(chrome.storage.session)chrome.storage.session.get('enhancementToken').then(value=>{enhancementToken=value.enhancementToken || '';$('enhance-token').value=enhancementToken;if(chrome.runtime.id)connectHelper();}).catch(()=>{});
setInterval(async()=>{try{const pending=(await readStore('tasks')).some(task=>task.autoDownload && !task.autoDownloadAttemptedAt && !['error','cancelled'].includes(task.state));if(pending || (workspaceView==='tasks' && !$('task-items').contains(document.activeElement)))await renderEnhancementTasks();}catch(error){$('tasks-status').textContent=error.message;}},3000);

$('helper-token-file').onchange=async()=>{try{const file=$('helper-token-file').files[0];if(!file)return;if(file.size>1024)throw new Error(E('连接文件过大。','Connection file is too large.'));const token=(await file.text()).trim();if(!/^[A-Za-z0-9_-]{20,128}$/.test(token))throw new Error(E('连接文件无效。','Invalid connection file.'));$('enhance-token').value=token;await connectHelper();}catch(error){$('helper-status').textContent=error.message;}finally{$('helper-token-file').value='';}};
$('compare-zoom').oninput=()=>{for(const id of ['enhance-original','enhance-output'])$(id).style.width=String(Number($('compare-zoom').value)*100)+'%';};
const compareSides=document.querySelectorAll('.enhance-comparison > div');for(const side of compareSides)side.addEventListener('scroll',()=>{const other=[...compareSides].find(item=>item!==side);if(!other)return;const x=side.scrollLeft/(side.scrollWidth-side.clientWidth || 1),y=side.scrollTop/(side.scrollHeight-side.clientHeight || 1);if(Math.abs(other.scrollLeft-x*(other.scrollWidth-other.clientWidth))>1)other.scrollLeft=x*(other.scrollWidth-other.clientWidth);if(Math.abs(other.scrollTop-y*(other.scrollHeight-other.clientHeight))>1)other.scrollTop=y*(other.scrollHeight-other.clientHeight);});

$('preview-seconds').onchange=updateEnhancementMode;setInterval(()=>{if($('enhance-panel').open && !helperHealth && !enhancementBusy)connectHelper();},3000);

window.addEventListener('wescreen-language',()=>{hdrChoice.lastChild.textContent=E('HDR 转 SDR（另存，原视频保留）','Convert HDR to SDR (save a copy)');});
