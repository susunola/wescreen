// Resolution is a source-dependent cap; quality selects bitrate, never invented pixels.
const captureResolutionHelp=document.createElement('p');captureResolutionHelp.id='capture-resolution-help';captureResolutionHelp.className='hint';$('record-summary').after(captureResolutionHelp);
function resolutionName(width,height){const long=Math.max(width,height),short=Math.min(width,height);return long>=7680&&short>=4320?'8K':long>=3840&&short>=2160?'4K':long>=2560&&short>=1440?'1440p':short>=1080?'1080p':short>=720?'720p':'';}
function updateCaptureQualityLabels(){
 $('framerate').querySelector('[value="0"]').textContent=E('原始帧率','Source frame rate');
 const select=$('resolution');for(const [value,zh,en] of [['native','原生像素','Native pixels'],['source','原始分辨率（随来源）','Source resolution'],['2160','4K · 3840×2160','4K · 3840×2160'],['1440','1440p · 2560×1440','1440p · 2560×1440'],['1080','1080p · 1920×1080','1080p · 1920×1080'],['720','720p · 1280×720','720p · 1280×720']]){const option=select.querySelector('[value="'+value+'"]');option.removeAttribute('data-i18n');option.textContent=E(zh,en);}
 const settings=displayStream?.getVideoTracks()[0]?.getSettings();
 const actual=settings?.width&&settings?.height;
 const prefix=['source','native'].includes(select.value)?(actual?(resolutionName(settings.width,settings.height)||settings.width+'×'+settings.height):E('原分辨率','Source resolution')):select.value==='2160'?'4K':select.value+'p';
 for(const [value,zh,en] of [['standard','标准码率','Standard bitrate'],['high','高码率','High bitrate'],['compact','省空间码率','Space-saving bitrate']]){const option=$('quality').querySelector('[value="'+value+'"]');option.removeAttribute('data-i18n');option.textContent=E(zh,en);}
 const compact=$('quality').querySelector('[value="compact"]');compact.disabled=false;
 for(const [value,type] of [['vp9','video/webm;codecs=vp9,opus'],['av1','video/webm;codecs=av1,opus']])$('format').querySelector('[value="'+value+'"]').disabled=!MediaRecorder.isTypeSupported(type);
 const heading=$('quality').closest('label').querySelector('span');heading.removeAttribute('data-i18n');heading.textContent=E('编码品质（码率）','Encoding quality (bitrate)');
 if(actual)captureResolutionHelp.textContent=E('实际采集：','Actual capture: ')+settings.width+'×'+settings.height+(resolutionName(settings.width,settings.height)?'（'+resolutionName(settings.width,settings.height)+'）':'')+' · '+(settings.frameRate||'?')+' fps · '+E('目标码率 ','Target bitrate ')+(videoBitrate(displayStream.getVideoTracks()[0])/1e6).toFixed(1)+' Mbps'+(recorder?.videoBitsPerSecond?' · '+E('编码器报告 ','Encoder reported ')+(recorder.videoBitsPerSecond/1e6).toFixed(1)+' Mbps':'');
 if(actual)captureResolutionHelp.textContent+=E(' · 预计约 ',' · Estimated ')+Math.round((videoBitrate(displayStream.getVideoTracks()[0])+captureAudioBitrate())*60/8/1e6)+E(' MB/分钟（实际取决于编码器）',' MB/min (encoder dependent)');
 if(actual){const caps=displayStream.getVideoTracks()[0].getCapabilities?.()||{};if(['native','source'].includes(select.value)&&caps.width?.max>settings.width*1.8&&caps.height?.max>settings.height*1.8)captureResolutionHelp.textContent+=E(' · 当前不是原生像素，请选择原生像素或重新共享。',' · Capture is below native dimensions; choose Native pixels or share again.');}
 else { const height=Number(select.value)||1080; const width=Math.round(height*16/9); const bits=videoBitrate({getSettings:()=>({width,height,frameRate:Number($('framerate').value)||30})})+captureAudioBitrate(); captureResolutionHelp.textContent=E('预计约 ','Estimated ')+(bits*3600/8/1e9).toFixed(1)+E(' GB/小时（按 16:9 估算，共享后更新）。建议只共享视频标签页；原生像素与高码率会显著增大文件。',' GB/hour (16:9 estimate; updates after sharing). Share only the video tab. Native pixels and high bitrate substantially increase file size.'); }
}
for(const id of ['resolution','quality','framerate','capture-content','capture-audio-quality'])$(id).addEventListener('change',updateCaptureQualityLabels);
for(const event of ['DOMContentLoaded','wescreen-language','wescreen-capture-settings'])window.addEventListener(event,updateCaptureQualityLabels);
const qualityApplyOutput=applyOutputSize;applyOutputSize=async stream=>{const result=await qualityApplyOutput(stream);updateCaptureQualityLabels();return result;};
updateCaptureQualityLabels();
