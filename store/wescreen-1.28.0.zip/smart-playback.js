// Background restoration overlays only synchronized, completed video chunks.
// The original video is always the audio/transport clock. Completed repairs persist in the authenticated local helper cache.
const smartBackground={enabled:false,generation:0,session:null,abort:null,busy:false,poll:null,callback:null,chunkSeconds:4,chunks:new Map(),available:new Map(),total:0,resume:false,bytes:0,current:-1,source:null,pending:null,failed:new Set(),status:null,stage:'',started:0,pendingStarted:0};
let smartCleanup=Promise.resolve(true);
let smartSubtitleTrack=null,smartSubtitleSource=null,smartSubtitleKey='';
const smartVideo=document.createElement('video');smartVideo.id='smart-restored-video';smartVideo.muted=true;smartVideo.playsInline=true;smartVideo.preload='auto';smartVideo.hidden=true;$('playback-stage').prepend(smartVideo);
function smartProgressText(){
 const info=smartBackground.status,elapsed=Math.max(0,Math.floor((performance.now()-(smartBackground.pendingStarted||smartBackground.started))/1000));
 if(smartBackground.stage==='error')return E('修复暂不可用 · 当前原画','Repair unavailable · Original');
 if(!smartBackground.session)return E('准备修复','Preparing repair')+` · ${elapsed}s`;
 if(smartWholeReady())return E('全片修复完成','Full repair ready');
 if(smartBackground.pending===null)return E('全片修复中','Repairing full video')+` · ${smartBackground.available.size}/${smartBackground.total}`;
 const progress=Math.max(0,Math.min(1,Number(info?.progress)||0)),percent=Math.floor(progress*100);
 const position=smartBackground.pending*smartBackground.chunkSeconds;
 const range=`${formatSmartTime(position)}–${formatSmartTime(position+smartBackground.chunkSeconds)}`;
 let timing=E(`已用 ${elapsed} 秒`,`Elapsed ${elapsed}s`);
 if(progress>=.1&&progress<.98&&elapsed>=2){const remaining=Math.max(1,Math.ceil(elapsed*(1-progress)/progress));timing=E(`预计还需约 ${remaining} 秒`,`About ${remaining}s remaining`);}
 else if(progress>=.98)timing=E('正在完成封装','Finalizing chunk');
 return E('修复片段','Repairing chunk')+` ${range} · ${percent}% · ${timing}`;
}
function formatSmartTime(seconds){return `${Math.floor(seconds/60).toString().padStart(2,'0')}:${Math.floor(seconds%60).toString().padStart(2,'0')}`;}
const smartWaiting=document.createElement('div');smartWaiting.className='smart-waiting';smartWaiting.hidden=true;smartWaiting.setAttribute('role','status');
const smartWaitingTitle=document.createElement('h3'),smartWaitingProgress=document.createElement('progress'),smartWaitingText=document.createElement('p');smartWaitingProgress.max=1;smartWaiting.append(smartWaitingTitle,smartWaitingProgress,smartWaitingText);$('playback-stage').append(smartWaiting);
function smartCurrentReady(){const index=Math.floor($('preview').currentTime/smartBackground.chunkSeconds);return smartBackground.enabled&&smartBackground.chunks.has(index);}
function smartWholeReady(){return smartBackground.enabled&&smartBackground.total>0&&smartBackground.available.size===smartBackground.total;}
function updateSmartBadge(){
 $('playback-stage').classList.toggle('smart-full-repair',smartBackground.enabled);
 const waiting=smartBackground.enabled&&!smartCurrentReady();smartWaiting.hidden=!waiting;$('rotated-play').disabled=false;$('playback-pip').disabled=waiting;
 if(waiting){smartWaitingTitle.textContent=E('正在准备下一段修复画面','Preparing the next restored segment');smartWaitingProgress.value=smartBackground.available.size/Math.max(1,smartBackground.total);smartWaitingText.textContent=smartProgressText()+E(' · 可切换原画或退出播放',' · Choose Original or close playback to cancel');}

 if(!smartBackground.enabled){enhancementBadge.hidden=!instantEnhancement;enhancementBadge.textContent=E('增强已开启','Enhancement on');enhancementBadge.removeAttribute('title');return;}
 enhancementBadge.hidden=false;
 const status=smartProgressText();
 enhancementBadge.textContent=smartVideo.hidden?status:E('智能最佳 · 修复版','Smart best · Restored version');
 const coverage=`${Math.floor(100*smartBackground.available.size/Math.max(1,smartBackground.total))}%`;
 enhancementBadge.textContent+=E(' · 全片 ',' · Whole video ')+coverage;
 enhancementBadge.title=status+E(' · 全片已缓存 ',' · Whole video cached ')+`${smartBackground.available.size}/${smartBackground.total}`;
 if(smartVideo.hidden)realtimeHint.textContent=enhancementBadge.title;
}
setInterval(()=>{if(smartBackground.enabled)updateSmartBadge();},1000);
new MutationObserver(updateSmartBadge).observe(smartVideo,{attributes:true,attributeFilter:['hidden']});
window.addEventListener('wescreen-language',updateSmartBadge);
function syncSmartLayout(){const v=$('preview');for(const key of ['width','height','transform'])smartVideo.style[key]=v.style[key];smartVideo.style.filter='none';}
new MutationObserver(syncSmartLayout).observe($('preview'),{attributes:true,attributeFilter:['style']});
function stopSmartBackground(){
 const old=smartBackground.session;smartBackground.enabled=false;smartBackground.generation++;smartBackground.abort?.abort();smartBackground.abort=null;clearTimeout(smartBackground.poll);smartBackground.poll=null;
 if(smartBackground.callback!==null){$('preview').cancelVideoFrameCallback?.(smartBackground.callback);cancelAnimationFrame(smartBackground.callback);}smartBackground.callback=null;
 smartSubtitleKey='';smartSubtitleSource=null;if(smartSubtitleTrack){smartSubtitleTrack.mode='disabled';for(const cue of [...(smartSubtitleTrack.cues||[])])smartSubtitleTrack.removeCue(cue);}
 smartVideo.hidden=true;smartVideo.pause();smartVideo.removeAttribute('src');smartVideo.load();
 for(const chunk of smartBackground.chunks.values())URL.revokeObjectURL(chunk.url);
 smartBackground.chunks.clear();smartBackground.available.clear();smartBackground.total=0;smartBackground.resume=false;smartBackground.failed.clear();smartBackground.bytes=0;smartBackground.current=-1;smartBackground.session=null;smartBackground.pending=null;smartBackground.busy=false;smartBackground.source=null;smartBackground.status=null;smartBackground.stage='';smartBackground.started=0;smartBackground.pendingStarted=0;
 updateSmartBadge();
 if(old){const request=enhancementRequest('/smart/'+old,{method:'DELETE',keepalive:true,signal:AbortSignal.timeout(15000)}).then(()=>true,()=>false);smartCleanup=Promise.all([smartCleanup,request]).then(results=>results.every(Boolean));}
 return smartCleanup;
}
function smartCachePut(index,blob,info){
 if(blob.size>128*1024*1024)throw new Error('Smart chunk exceeds browser cache limit');
 const previous=smartBackground.chunks.get(index);if(previous){URL.revokeObjectURL(previous.url);smartBackground.bytes-=previous.size;}
 smartBackground.chunks.delete(index);smartBackground.chunks.set(index,{url:URL.createObjectURL(blob),size:blob.size,info});smartBackground.bytes+=blob.size;
 for(const [key,chunk] of smartBackground.chunks){if(smartBackground.bytes<=128*1024*1024&&smartBackground.chunks.size<=6)break;if(key===smartBackground.current||key===index)continue;URL.revokeObjectURL(chunk.url);smartBackground.bytes-=chunk.size;smartBackground.chunks.delete(key);}
 if(smartBackground.bytes>128*1024*1024){const current=smartBackground.chunks.get(smartBackground.current);if(current&&smartBackground.current!==index){smartVideo.hidden=true;smartVideo.pause();smartVideo.removeAttribute('src');URL.revokeObjectURL(current.url);smartBackground.bytes-=current.size;smartBackground.chunks.delete(smartBackground.current);smartBackground.current=-1;}}
}
function smartStatus(info){
 smartBackground.status=info||null;smartBackground.stage=info?.state==='error'?'error':'';updateSmartBadge();
 const analysis=info?.analysis;
 realtimeHint.textContent=info?.state==='done'?(info.engine||E('保守修复','Conservative repair'))+E(' · 已缓存，可直接观看',' · Cached for playback')+(analysis?.soft?E(' · 低细节来源',' · Soft source'):''):E('修复下一段 · 完成后继续播放修复版','Repairing the next segment · Restored playback resumes when ready');
}
function scheduleSmartPresentation(){
 if(!smartBackground.enabled||smartBackground.callback!==null||$('preview').paused)return;
 const v=$('preview');const tick=()=>{smartBackground.callback=null;if(!smartBackground.enabled)return;presentSmartChunk();scheduleSmartPresentation();};
 smartBackground.callback=v.requestVideoFrameCallback?v.requestVideoFrameCallback(tick):requestAnimationFrame(tick);
}
function syncSmartSubtitles(start){
 const source=typeof playerSubtitleTrack!=='undefined'?playerSubtitleTrack?.track:null;
 const cues=source?.cues;const key=[smartBackground.current,cues?.length,cues?.[0]?.startTime,cues?.[0]?.text,source?.mode].join('|');
 if(key===smartSubtitleKey&&source===smartSubtitleSource)return;
 smartSubtitleKey=key;smartSubtitleSource=source;
 if(!smartSubtitleTrack&&source)smartSubtitleTrack=smartVideo.addTextTrack('subtitles');
 if(!smartSubtitleTrack)return;
 for(const cue of [...(smartSubtitleTrack.cues||[])])smartSubtitleTrack.removeCue(cue);
 smartSubtitleTrack.mode=source?.mode==='showing'?'showing':'disabled';
 if(!cues)return;
 for(const cue of [...cues]){if(cue.endTime<=start||cue.startTime>=start+smartVideo.duration)continue;const item=new VTTCue(Math.max(0,cue.startTime-start),cue.endTime-start,cue.text);for(const prop of ['line','align','position','size','vertical'])item[prop]=cue[prop];smartSubtitleTrack.addCue(item);}
}
function presentSmartChunk(){
 const v=$('preview');if(smartBackground.enabled&&!smartCurrentReady()&&!v.paused){smartBackground.resume=true;v.pause();pumpSmartChunks();}
 if(!smartCurrentReady()||playbackSeeking||document.hidden||!$('player-view').getClientRects().length){smartVideo.hidden=true;return;}
 const index=Math.floor(v.currentTime/smartBackground.chunkSeconds),chunk=smartBackground.chunks.get(index);
 if(!chunk){smartVideo.hidden=true;smartVideo.pause();return;}
 if(index!==smartBackground.current){smartBackground.current=index;smartVideo.hidden=true;smartVideo.pause();smartVideo.src=chunk.url;smartVideo.load();smartStatus(chunk.info);}
 if(smartVideo.readyState<2){smartVideo.hidden=true;return;}
 const time=v.currentTime-chunk.info.start;
 const drift=time-smartVideo.currentTime;
 if(time<0||time>=smartVideo.duration){smartVideo.hidden=true;return;}
 if(Math.abs(drift)>(v.paused?.015:.35)){smartVideo.hidden=true;if(!smartVideo.seeking)smartVideo.currentTime=Math.max(0,Math.min(time,smartVideo.duration||time));if(!v.paused)smartVideo.play().catch(()=>{});return;}
 // Catch up while hidden rather than repeatedly seeking a moving clock.
 smartVideo.playbackRate=v.playbackRate*(Math.abs(drift)>.06?(drift>0?1.2:.8):1);
 if(v.paused)smartVideo.pause();else if(smartVideo.paused)smartVideo.play().catch(()=>{smartVideo.hidden=true;});
 syncSmartLayout();syncSmartSubtitles(chunk.info.start);realtimeCanvas.hidden=true;
 smartVideo.hidden=smartVideo.seeking||Math.abs(drift)>(smartVideo.hidden?.06:.12)||(!v.paused&&smartVideo.paused);
 if(!smartVideo.hidden&&smartBackground.resume){smartBackground.resume=false;v.play().catch(()=>{});}
}
async function pumpSmartChunks(){
 if(!smartBackground.enabled||smartBackground.busy||!smartBackground.session)return;
 const generation=smartBackground.generation,session=smartBackground.session,v=$('preview');smartBackground.busy=true;
 const controller=new AbortController();smartBackground.abort=controller;
 try{
   // Fetch existing repairs on demand; browser RAM eviction never triggers repair.
   const cached=[Math.floor(v.currentTime/smartBackground.chunkSeconds),Math.floor(v.currentTime/smartBackground.chunkSeconds)+1].find(i=>smartBackground.available.has(i)&&!smartBackground.chunks.has(i));
   if(cached!==undefined){
    const blob=await(await enhancementRequest(`/smart/${session}/chunks/${cached}?result=1`,{signal:controller.signal})).blob();
    if(generation!==smartBackground.generation)return;
    smartCachePut(cached,blob,smartBackground.available.get(cached));presentSmartChunk();
   }
  if(smartBackground.pending!==null){
   const wanted=Math.floor(v.currentTime/smartBackground.chunkSeconds);
   if(!smartBackground.available.has(wanted)&&!smartBackground.failed.has(wanted)&&Math.abs(smartBackground.pending-wanted)>1){
    await enhancementRequest(`/smart/${session}/chunks/${smartBackground.pending}`,{method:'DELETE',signal:controller.signal});
    if(generation!==smartBackground.generation)return;
    smartBackground.pending=null;smartBackground.status=null;smartBackground.stage='';
    return;
   }
   const index=smartBackground.pending,info=await(await enhancementRequest(`/smart/${session}/chunks/${index}`,{signal:controller.signal})).json();
   if(generation!==smartBackground.generation)return;
   smartStatus(info);
   if(info.state==='done'){
    const near=Math.abs(index-Math.floor(v.currentTime/smartBackground.chunkSeconds))<=1;
    const blob=near?await(await enhancementRequest(`/smart/${session}/chunks/${index}?result=1`,{signal:controller.signal})).blob():null;
    if(generation!==smartBackground.generation)return;
    smartBackground.pending=null;smartBackground.available.set(index,info);try{if(blob)smartCachePut(index,blob,info);}catch(error){smartBackground.failed.add(index);throw error;}presentSmartChunk();
   }else if(info.state==='error'){smartBackground.pending=null;smartBackground.failed.add(index);throw new Error(info.error||'Smart repair failed');}
  }else{
   const current=Math.floor(v.currentTime/smartBackground.chunkSeconds),count=Math.ceil(v.duration/smartBackground.chunkSeconds);
   const candidates=[current,current+1,current+2,...Array.from({length:count},(_,i)=>i)];
   const index=candidates.find(i=>i<count&&!smartBackground.available.has(i)&&!smartBackground.failed.has(i));
   if(index!==undefined){await enhancementRequest(`/smart/${session}/chunks/${index}`,{method:'POST',signal:controller.signal});if(generation!==smartBackground.generation)return;smartBackground.pending=index;smartBackground.pendingStarted=performance.now();smartStatus({state:'queued',progress:0});}
  }
 }catch(error){if(generation===smartBackground.generation&&error.name!=='AbortError'){smartBackground.stage='error';updateSmartBadge();realtimeHint.textContent=E('当前片段修复未完成，等待修复或切换原画播放。','This segment is not ready. Wait for repair or choose Original.');}}
 finally{if(generation===smartBackground.generation){smartBackground.busy=false;clearTimeout(smartBackground.poll);smartBackground.poll=setTimeout(pumpSmartChunks,smartBackground.pending===null&&smartBackground.available.size<smartBackground.total?100:1000);}}
}
async function startSmartBackground(health,entry){
 if(!health?.smartChunks || !(finalBlob instanceof Blob) || typeof playerColor!=='undefined'&&playerColor.mode==='hdr')return false;
 const expectedSource=$('preview').currentSrc;await stopSmartBackground();if(expectedSource!==$('preview').currentSrc)return false;stopRealtimeAI();
 const resumePlaying=!$('preview').paused;$('preview').pause();smartBackground.enabled=true;smartBackground.resume=resumePlaying;smartBackground.started=performance.now();updateSmartBadge();smartBackground.source=$('preview').currentSrc;const generation=++smartBackground.generation;
 realtimeHint.textContent=E('正在准备本机修复缓存 · 可继续播放','Preparing local repair cache · Playback continues');
 const controller=new AbortController();smartBackground.abort=controller;
 try{
  const result=await(await enhancementRequest('/smart/sources?content='+encodeURIComponent(entry?.captureContent||'auto'),{method:'POST',body:finalBlob,headers:{'Content-Type':finalBlob.type||'application/octet-stream'},signal:controller.signal})).json();
  if(generation!==smartBackground.generation){enhancementRequest('/smart/'+result.id,{method:'DELETE'}).catch(()=>{});return false;}
  smartCleanup=Promise.resolve(true);smartBackground.session=result.id;smartBackground.chunkSeconds=result.chunkSeconds;smartBackground.available=new Map(Object.entries(result.completed||{}).map(([i,info])=>[Number(i),info]));smartBackground.total=result.totalChunks||Math.ceil($('preview').duration/result.chunkSeconds);realtimeButton.setAttribute('aria-pressed','true');
  pumpSmartChunks();scheduleSmartPresentation();return true;
 }catch(error){if(generation===smartBackground.generation){stopSmartBackground();realtimeHint.textContent=E('全片修复无法启动，请连接本机程序后重试。','Full repair unavailable. Connect the local helper and retry.');}return false;}
}
$('preview').addEventListener('play',()=>{if(smartBackground.enabled&&!smartCurrentReady()){smartBackground.resume=true;$('preview').pause();updateSmartBadge();pumpSmartChunks();return;}presentSmartChunk();scheduleSmartPresentation();});
$('preview').addEventListener('pause',()=>{smartVideo.pause();presentSmartChunk();});
$('preview').addEventListener('seeking',()=>{smartVideo.hidden=true;smartVideo.pause();});
$('preview').addEventListener('seeked',()=>{presentSmartChunk();pumpSmartChunks();});
smartVideo.addEventListener('loadeddata',presentSmartChunk);smartVideo.addEventListener('seeked',presentSmartChunk);
$('preview').addEventListener('emptied',()=>stopSmartBackground());
window.addEventListener('pagehide',stopSmartBackground);
new MutationObserver(()=>{if($('player-view').classList.contains('hidden'))stopSmartBackground();}).observe($('player-view'),{attributes:true,attributeFilter:['class']});
originalPicture.addEventListener('click',stopSmartBackground);
// Hold-to-compare uses the same original preview underneath both enhancement layers.

async function resumeSmartPart(){
 const generation=playbackGeneration,source=$('preview').currentSrc;
 const color=await playerColorReady;if(generation!==playbackGeneration||source!==$('preview').currentSrc||color.mode==='hdr')return;
 const health=await connectHelper();if(generation!==playbackGeneration||source!==$('preview').currentSrc)return;
 const entry=activePlaybackId?await readStore('recordings',activePlaybackId):null;
 if(generation!==playbackGeneration||source!==$('preview').currentSrc)return;
 if(await startSmartBackground(health,entry))displaySelectedQuality('smart');
}
