// The primary quality menu has exactly three choices. Advanced controls live under More.
const advancedQuality=document.createElement('details');advancedQuality.id='player-quality-advanced';advancedQuality.className='advanced';advancedQuality.append(polishLabel(document.createElement('summary'),'画质高级设置','Advanced picture settings'));
const qualityKeep=new Set([originalPicture,realtimeButton,$('playback-ai')]);
for(const node of [...qualityPanel.children])if(!qualityKeep.has(node))advancedQuality.append(node);
morePanel.append(advancedQuality);
advancedQuality.querySelector('.cinema-menu-heading')?.remove();advancedQuality.querySelector('[data-i18n=repairCaption]')?.remove();
realtimePreference.hidden=true; // One honest balanced policy; no unused strategy selector.
$('playback-enhance').removeAttribute('data-i18n');polishLabel($('playback-enhance'),'后台精修设置 ›','Background restoration settings ›');
const protectionLabel=$('realtime-text-protect').closest('label');protectionLabel.classList.add('quality-setting-toggle');protectionLabel.prepend($('realtime-text-protect'));

originalPicture.removeAttribute('data-i18n');realtimeButton.removeAttribute('data-i18n');$('playback-ai').removeAttribute('data-i18n');
polishLabel(originalPicture,'原画','Original');polishLabel(realtimeButton,'智能最佳','Smart best');polishLabel($('playback-ai'),'AI 高清修复','AI HD repair');
qualityPanel.classList.add('simple-quality');qualityPanel.replaceChildren(originalPicture,realtimeButton,$('playback-ai'));
const qualityCaption=qualityMenu.querySelector('summary');qualityCaption.removeAttribute('data-i18n');
let selectedQuality='original',qualityStateGeneration=0;
function displaySelectedQuality(mode){selectedQuality=mode;const labels={original:['原画','Original'],smart:['智能最佳','Smart best'],repair:['AI 高清修复','AI HD repair']};qualityCaption.textContent=E(...labels[mode]);qualityCaption.title=E('当前画质：','Current quality: ')+qualityCaption.textContent;qualityCaption.setAttribute('aria-label',qualityCaption.title);for(const [button,key] of [[originalPicture,'original'],[realtimeButton,'smart'],[$('playback-ai'),'repair']]){button.classList.toggle('quality-selected',key===mode);button.setAttribute('aria-pressed',String(key===mode));}}
async function refreshSelectedQuality(){const generation=++qualityStateGeneration,entry=activePlaybackId?await readStore('recordings',activePlaybackId):null;if(generation!==qualityStateGeneration)return;displaySelectedQuality(smartBackground.enabled||realtimeAI.enabled||instantEnhancement||nativeSmartHDR?'smart':entry&&['ai','strong'].includes(entry.enhancement)?'repair':'original');}
const originalClick=originalPicture.onclick;
originalPicture.onclick=async()=>{nativeSmartHDR=false;try{stopRealtimeAI();originalClick();const entry=activePlaybackId?await readStore('recordings',activePlaybackId):null;if(entry&&['ai','strong'].includes(entry.enhancement)&&entry.enhancedFrom){const source=await readStore('recordings',entry.enhancedFrom);if(!source||source.deletedAt)throw new Error(E('原视频已删除。','Original video was deleted.'));pendingPlaybackPosition={id:source.id,time:$('preview').currentTime,playing:!$('preview').paused};await playRecording(source);}displaySelectedQuality('original');qualityMenu.open=false;}catch(error){$('playback-status').textContent=error.message;}};
const smartClick=realtimeButton.onclick;
realtimeButton.onclick=async()=>{const generation=playbackGeneration;const color=await playerColorReady;if(generation!==playbackGeneration)return;if(color.mode==='hdr'){stopRealtimeAI();instantEnhancement=null;nativeSmartHDR=true;$('preview').style.filter='none';displaySelectedQuality('smart');qualityMenu.open=false;$('playback-status').textContent=E('HDR 原生播放 · 保留高光与色彩；实际 HDR 显示取决于浏览器和屏幕。','Native HDR playback · Display capability depends on the browser and screen.');return;}if(smartBackground.enabled||realtimeAI.enabled||instantEnhancement){qualityMenu.open=false;return;}const entry=activePlaybackId?await readStore('recordings',activePlaybackId):null;const health=await connectHelper();if(generation!==playbackGeneration)return;if(await startSmartBackground(health,entry)){displaySelectedQuality('smart');qualityMenu.open=false;return;}displaySelectedQuality('original');qualityMenu.open=false;$('playback-status').textContent=E('全片修复未启动，请连接本机程序后重试；当前为原画。','Full repair did not start. Connect the local helper and retry; Original is selected.');};
const repairClick=$('playback-ai').onclick;$('playback-ai').onclick=async()=>{qualityMenu.open=false;await repairClick();refreshSelectedQuality().catch(()=>{});};
const oldStopRealtime=stopRealtimeAI;stopRealtimeAI=function(message=''){oldStopRealtime(message);refreshSelectedQuality().catch(()=>{});};
$('preview').addEventListener('loadedmetadata',()=>refreshSelectedQuality().catch(()=>{}));
$('playback-instant').addEventListener('click',()=>refreshSelectedQuality().catch(()=>{}));
window.addEventListener('wescreen-language',()=>displaySelectedQuality(selectedQuality));displaySelectedQuality('original');
