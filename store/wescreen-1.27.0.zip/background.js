chrome.commands.onCommand.addListener(command=>chrome.runtime.sendMessage({type:command}).catch(()=>{}));
let highlightGeneration=0;
async function updateRecordingState(message,sender={}) {
  const generation=++highlightGeneration;
  const state=await chrome.storage.session.get(['pointerTargetTabId','recordingOwner']);
  if(generation!==highlightGeneration)return;
  const owner=state.recordingOwner;
  if(!message.active && owner?.tabId && sender.tab?.id && sender.tab.id!==owner.tabId)return;
  const target=message.active ? state.pointerTargetTabId : owner?.targetId ?? state.pointerTargetTabId;
  chrome.action.setBadgeText({text:message.active ? 'REC':''});chrome.action.setBadgeBackgroundColor({color:'#c21f3a'});
  if(message.active && sender.tab?.id)await chrome.storage.session.set({recordingOwner:{tabId:sender.tab.id,targetId:target}});
  else if(chrome.storage.session.remove)await chrome.storage.session.remove('recordingOwner');
  if(generation!==highlightGeneration)return;
  if(target!=null)await chrome.tabs.sendMessage(target,{type:'click-highlights-state',active:Boolean(message.active && message.highlightClicks)}).catch(()=>{});
}
chrome.runtime.onMessage.addListener((message,sender)=>{if(message.type==='recording-state')updateRecordingState(message,sender).catch(()=>{});});
chrome.tabs.onRemoved?.addListener(async tabId=>{const {recordingOwner}=await chrome.storage.session.get('recordingOwner');if(recordingOwner?.tabId===tabId)await updateRecordingState({active:false});});
chrome.runtime.onStartup?.addListener(()=>{chrome.action.setBadgeText({text:''});chrome.storage.session.remove('recordingOwner').catch(()=>{});});

chrome.runtime.onMessage.addListener((message,sender,respond)=>{
 if(message.type!=='recorder-control')return;
 if(sender.url!==chrome.runtime.getURL('controls.html') || !['stop-recording','pause-recording','mark-important','get-recording-status'].includes(message.action)){respond({error:'Unsupported control request'});return;}
 chrome.storage.session.get('recordingOwner').then(async({recordingOwner})=>{if(!recordingOwner?.tabId)return respond({active:false});try{respond(await chrome.tabs.sendMessage(recordingOwner.tabId,{type:message.action}));}catch{respond({active:false});}}).catch(error=>respond({error:error.message}));return true;
});

chrome.runtime.onMessage.addListener((message,sender,respond)=>{
 if(message.type!=='original-tab-stream')return;
 if(sender.url!==chrome.runtime.getURL('recorder.html') || !sender.tab?.id){respond({error:'Unsupported capture request'});return;}
 (async()=>{
  if(!await chrome.permissions.contains({permissions:['tabCapture']}))throw new Error('Tab capture permission is required');
  const {pointerTargetTabId}=await chrome.storage.session.get('pointerTargetTabId');
  if(!pointerTargetTabId || pointerTargetTabId===sender.tab.id){respond({error:'Original source tab is not selected',code:'SOURCE_TAB_REQUIRED'});return;}
  const target=await chrome.tabs.get(pointerTargetTabId);
  if(!/^https?:\/\//i.test(target.url || ''))throw new Error('原视频标签页不可访问，请重新点击扩展 / Reopen WeScreen from the video tab');
  const streamId=await chrome.tabCapture.getMediaStreamId({targetTabId:pointerTargetTabId,consumerTabId:sender.tab.id});respond({streamId});
 })().catch(error=>respond({error:error.message}));return true;
});

// Only the explicitly selected source tab is modified; restore it on stop or owner close.
async function restoreQuietAudio(ownerId) {
 const {quietCaptureOwner}=await chrome.storage.session.get('quietCaptureOwner');
 if(!quietCaptureOwner || quietCaptureOwner.ownerId!==ownerId)return;
 await chrome.scripting.executeScript({target:{tabId:quietCaptureOwner.targetId},world:'MAIN',func:()=>{
  const state=window.__wescreenQuietAudio;
  if(!state)return;
  clearInterval(state.timer);state.video.removeEventListener('volumechange',state.enforce);
  state.video.muted=state.muted;state.video.volume=state.volume;delete window.__wescreenQuietAudio;
 }}).catch(()=>{});
 await chrome.storage.session.remove('quietCaptureOwner');
}
chrome.tabs.onRemoved?.addListener(tabId=>restoreQuietAudio(tabId).catch(()=>{}));
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
 if(message.type!=='quiet-tab-audio')return;
 if(sender.url!==chrome.runtime.getURL('recorder.html') || !sender.tab?.id){respond({error:'Unsupported audio request'});return;}
 (async()=>{
  if(!message.active){await restoreQuietAudio(sender.tab.id);return respond({ok:true});}
  if(!await chrome.permissions.contains({permissions:['tabCapture']}))throw new Error('Tab capture permission is required');
  const {pointerTargetTabId,quietCaptureOwner}=await chrome.storage.session.get(['pointerTargetTabId','quietCaptureOwner']);
  if(quietCaptureOwner)throw new Error('已有静音录制，请先停止 / Stop the existing silent recording first');
  if(!pointerTargetTabId || pointerTargetTabId===sender.tab.id)throw new Error('请从视频标签页打开扩展 / Open WeScreen from the video tab');
  const [result]=await chrome.scripting.executeScript({target:{tabId:pointerTargetTabId},world:'MAIN',func:()=>{
   const videos=[...document.querySelectorAll('video')].filter(video=>{const r=video.getBoundingClientRect();return r.width>0 && r.height>0 && getComputedStyle(video).visibility!=='hidden';});
   videos.sort((a,b)=>{const x=a.getBoundingClientRect(),y=b.getBoundingClientRect();return y.width*y.height-x.width*x.height;});
   const video=videos[0];if(!video)return false;
   const state={video,muted:video.muted,volume:video.volume};
   state.enforce=()=>{if(video.muted)video.muted=false;if(video.volume!==1)video.volume=1;};
   state.enforce();video.addEventListener('volumechange',state.enforce);window.__wescreenQuietAudio=state;
   // Navigation discards the document; removing/replacing the player restores its old state.
   state.timer=setInterval(()=>{if(!video.isConnected){clearInterval(state.timer);video.removeEventListener('volumechange',state.enforce);video.muted=state.muted;video.volume=state.volume;delete window.__wescreenQuietAudio;}},1000);
   return true;
  }});
  if(!result?.result)throw new Error('未找到网页视频播放器。请打开视频后重试 / Open the web video player and retry');
  await chrome.storage.session.set({quietCaptureOwner:{ownerId:sender.tab.id,targetId:pointerTargetTabId}});respond({ok:true});
 })().catch(error=>respond({error:error.message}));return true;
});

// Read only the user's selected recording source, with an exact message/video match.
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
 if(message.type!=='telegram-source-status')return;
 if(sender.url!==chrome.runtime.getURL('recorder.html')||!sender.tab?.id){respond({error:'Unsupported source request'});return;}
 (async()=>{
  const state=await chrome.storage.session.get(['pointerTargetTabId','recordingOwner']);
  const targetId=state.recordingOwner?.tabId===sender.tab.id?state.recordingOwner.targetId:state.pointerTargetTabId;
  if(!targetId||targetId===sender.tab.id)return respond({available:false});
  const tab=await chrome.tabs.get(targetId);if(new URL(tab.url).hostname!=='web.telegram.org')return respond({available:false,wrongSource:true});
  if(!/^\d+$/.test(String(message.messageId)))return respond({available:true,verified:false});
  const [result]=await chrome.scripting.executeScript({target:{tabId:targetId},world:'MAIN',args:[String(message.messageId),String(message.channelKey||'')],func:(id,key)=>{
   const visible=[...document.querySelectorAll('video')].filter(v=>{const r=v.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(v).visibility!=='hidden';}).sort((a,b)=>{const x=a.getBoundingClientRect(),y=b.getBoundingClientRect();return y.width*y.height-x.width*x.height;});
   const player=visible[0];if(!player)return {available:true,verified:false};
   const target=[...document.querySelectorAll('[data-mid],[data-message-id]')].filter(el=>el.getAttribute('data-mid')===id||el.getAttribute('data-message-id')===id).flatMap(el=>[...el.querySelectorAll('video')]);
   const hashTokens=decodeURIComponent(location.hash).toLowerCase().split(/[^a-z0-9_@-]+/).filter(Boolean);
   const channel=key.split(':')[1],privateChannel=key.startsWith('private:');
   const channelMatches=channel&&(privateChannel?hashTokens.some(t=>t===channel||t==='-100'+channel):hashTokens.some(t=>t==='@'+channel.toLowerCase()));
   const scoped=target.filter(v=>{const peer=v.closest('[data-peer-id]')?.getAttribute('data-peer-id');return channelMatches||(privateChannel&&(peer===channel||peer==='-100'+channel));});
   const verified=scoped.some(v=>v===player||(v.currentSrc&&v.currentSrc===player.currentSrc));
   const rect=player.getBoundingClientRect(),vw=innerWidth,vh=innerHeight;
   let x=rect.left,y=rect.top,width=rect.width,height=rect.height;
   const style=getComputedStyle(player);
   if(style.objectFit==='contain'&&style.objectPosition==='50% 50%'&&player.videoWidth&&player.videoHeight){const scale=Math.min(width/player.videoWidth,height/player.videoHeight),w=player.videoWidth*scale,h=player.videoHeight*scale;x+=(width-w)/2;y+=(height-h)/2;width=w;height=h;}
   const region=verified&&style.transform==='none'&&width>2&&height>2&&x>=0&&y>=0&&x+width<=vw+1&&y+height<=vh+1?{x:x/vw,y:y/vh,width:width/vw,height:height/vh}:null;
   return {available:true,verified,region,paused:player.paused,readyState:player.readyState,ended:verified&&player.ended,time:verified?player.currentTime:0,duration:verified&&Number.isFinite(player.duration)?player.duration:0,videoWidth:player.videoWidth,videoHeight:player.videoHeight};
  }});respond(result?.result || {available:false});
 })().catch(()=>respond({available:false}));return true;
});
